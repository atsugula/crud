<?php
	
	include_once "conexion.php";
	class producto{

		private $id;
		private $cod;
		private $descripcion;
		private $stock;
 
		private $con;

		public function __construct(){

			$this->con=new conexion();

		}//fin del metodo construct	

		public function set($atributo,$contenido){
			$this->$atributo=$contenido;
		}

		public function get($atributo){
			return $this->$atributo;

		}
		//METODOS CRUD

		public function crear(){

			$sql="SELECT * FROM producto WHERE cod='{$this->cod}'";
			
			$resultado=$this->con->consultaRetorno($sql);

			$filas=mysqli_num_rows($resultado);

			echo "filas--> $filas";

			if($filas==0){

				$sql="INSERT INTO producto(cod,descripcion,stock) VALUES ('{$this->cod}','{$this->descripcion}','{$this->stock}')";
				/*echo $sql;*/
				$this->con->consultaSimple($sql);
				return true;

			}else{
				return false;
			}

		}//fin del metodo crear

		public function eliminar(){
			$sql="DELETE FROM producto WHERE id = '{$this->id}'";
			$this->con->consultaSimple($sql);
		}//fin del metodo eliminar

		public function editar(){
			$sql="UPDATE producto SET 	
					cod = '{$this->cod}',
					descripcion = '{$this->descripcion}',
					stock = '{$this->stock}'
					WHERE id = '{$this->id}'";

			$this->con->consultaSimple($sql);
			return true;
		}//fin del metodo editar

		public function ver(){
			$sql="SELECT cod,descripcion,stock FROM producto WHERE id ='{$this->id}'";

			$resultado=$this->con->consultaRetorno($sql);
			
			$reg=mysqli_fetch_assoc($resultado);

			$this->cod=$reg["cod"];
			$this->descripcion=$reg["descripcion"];
			$this->stock=$reg["stock"];
			/*var_dump($reg);*/

			return $reg;
		}//fin del metood ver

		public function listar(){
			$sql="SELECT * FROM producto";
			$resultado=$this->con->consultaRetorno($sql);
			return $resultado;
		}//fin del metodo listar

	}//fin del objeto persona

	/*$temporal=new persona();

	$temporal->persona->set("id","3");

	$temporal->persona->ver();

*/

?>