<?php

	class conexion{

	private $host;
	private $user;
	private $pass;
	private $bd;
	private $con;

	//metodos

	public function __construct(){
		$this->host="localhost";
		$this->user="root";
		$this->pass="";
		$this->bd="eva";
		$this->con=mysqli_connect($this->host,$this->user,$this->pass,$this->bd);

		if(mysqli_connect_error($this->con)){
			echo "fallo en la conexión a la BD $this->bd";
		}else{
			echo "conexión exitosa a la BD $this->bd";
		}

	}//fin del metodo constructor

	public function consultaSimple($sql){
		mysqli_query($this->con,$sql);
	}//fin del metodo consulta simple

	public function consultaRetorno($sql){
		$resultado=mysqli_query($this->con,$sql);
		return $resultado;
	}

}//fin del objeto de conexion
	//$temporal=new conexion();
?>