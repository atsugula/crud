<?php

	include_once "controlador/enrutador.php";
	include_once "controlador/productos.php";
?>

<!DOCTYPE html>
<html>
<head>	
	<title>Green Bear</title>
	<link rel="icon" href="vistas/img/plantilla/beer.png">
</head>
<body>
	<h1>Creacion de (CRUD) PRODUCTOS</h1>

	<nav>
		<ul>
			<li><a href="index.php"tittle="">Inicio</a></li>
			<li><a href="index.php?cargar=crear"tittle="">Registrar Producto</a></li>
		</ul>

	</nav>

	<section>

		<?php

			error_reporting(E_ALL ^ E_NOTICE);

			$enrutador=new enrutador();

			if ($enrutador->validarVista($_GET["cargar"]))
				$enrutador->cargarVista($_GET["cargar"]);
		?>
	</section>

</body>
</html>