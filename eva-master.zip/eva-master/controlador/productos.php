<?php 
	include_once("modelos/producto.php");

	class controlador{

		private $producto;

		public function __construct(){

			$this->producto=new producto();

		}//fin del metodo constructor

		public function index(){

			$resultado=$this->producto->listar();
			return $resultado;

		}//fin del index
        public function crear($cod,$descripcion,$stock){

			$this->producto->set("cod",$cod);
			$this->producto->set("descripcion",$descripcion);
			$this->producto->set("stock",$stock);
			
			$resultado= $this->producto->crear();
			return $resultado;

		}//fin del metodo crear

		//FUNCION ELIMINAR

		public function eliminar($id){

			$this->producto->set("id",$id);
			$this->producto->eliminar();

		}//fin funcion eliminar

		//FUNCION VER

		public function ver($id){

			$this->producto->set("id",$id);
			return $this->producto->ver();

		}//fin funcion VER

		//FUNCION EDITAR

	    public function editar($id,$cod,$descripcion,$stock){

	    	$this->producto->set("id",$id);
			$this->producto->set("cod",$cod);
			$this->producto->set("descripcion",$descripcion);
			$this->producto->set("stock",$stock);
			$this->producto->editar();
			return true;

		}//fin funcion editar

	}//fin del objeto controladorproducto






 ?>