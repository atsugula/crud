<?php

	class enrutador{

		public function cargarVista($vista){

			if ($vista=='crear'||
				$vista=='ver'||
				$vista=='editar'||
				$vista=='eliminar'){

					include_once("vistas/".$vista.".php");
			}else{
					include_once("vistas/error404.php");
			}
			
		}//fin del metodo cargar vista

		public function validarVista($variable){

			if(empty($variable)){
				include_once "vistas/inicio.php";
			}else{
				return true;
			}
		}
	}//fin clase enrutador


?>