<h2>ESTAS EN EL MÓDULO DE REGISTRO PRODUCTO</h2>

<form method="post">
	<table border="2">
	<tr>
		<th>CODIGO DEL PRODUCTO: <br></th>
		<th><input type="text" name="cod" required><br></th>
	</tr>
	<tr>
		<th>DESCRIPCION DEL PRODUCTO: <br></th>
		<th><input type="text" name="descripcion" required><br></th>
	</tr>
	<tr>
		<th>STOCK DEL PRODUCTO: <br></th>
		<th><input type="text" name="stock" required><br></th>
	</tr>
	<tr>
		<th><input type="submit" name="enviar" value="REGISTRAR"></th>
	</tr>
	</table>
</form>

 <?php 

	$controlador=new controlador();//para crear productos antes hay que iniciarlo

	if (isset($_POST["enviar"])){
			$res=$controlador->crear($_POST["cod"],$_POST["descripcion"],$_POST["stock"]);
	echo $res;

	if($_POST["stock"]<=5){
				echo "	<script>
							alert('STOCK MENOR A 5');
						</script>";	

			}

	if($res){
		echo "<script>
			alert('PRODUCTO REGISTRADO');
			window.location='index.php'
			</script>";
		//header("location:index.php");
			
		

	}else{
		echo "<script>alert('CODIGO PRODUCTO DUPLICADO');</script>";
		

	}

}

?>
