<?php 

	$controlador = new controlador();
	$resultado=$controlador->index();

 ?>
<h3>Página de inicio PRODUCTOS</h3>
 	<table border="1">
	<thead>
		<tr>
			<td>ID</td>
			<td>CODIGO DEL PRODUCTO</td>
			<td>DESCRIPCION DEL PRODUCTO</td>
			<td>STOCK DEL PRODUCTO</td>
			<td>ACCIONES</td>
		</tr>
	</thead>
	<tbody>
		<?php 
			while ($reg=mysqli_fetch_assoc($resultado)){
				echo "<tr>";
				echo "<td>".$reg["id"]."</td>";
				echo "<td>".$reg["cod"]."</td>";
				echo "<td>".$reg["descripcion"]."</td>";
				if($reg["stock"]<=5){
				echo "	<style>
							.lol{
								background-color: red;
							}
							.loli{
								background-color: green;
							}
						</style>
						<td class='lol'>".$reg["stock"]."</td>
						";

			}else{
				echo "<td class='loli' >".$reg["stock"]."</td>";
			}
				echo '	<td>
							<a href="index.php?cargar=ver&id='.$reg["id"].'">VER</a>
							<a href="index.php?cargar=editar&id='.$reg["id"].'">EDITAR</a>
							<a href="index.php?cargar=eliminar&id='.$reg["id"].'">ELIMINAR</a>
						</td>';
			}

		 ?>

	</tbody>

</table>