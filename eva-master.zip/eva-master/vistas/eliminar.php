		<h2>¿Desea eliminar este Producto?</h2>
		<form method="post">
			
				<input type="submit" name="si" value="Si">
				<input type="submit" name="no" value="No">
				
		</form>

<?php
		$controlador=new controlador();

		if(isset($_POST["si"])){
			echo "<h1>Producto Eliminado Correctamente</h1>";
			"<br>";
			$reg=$controlador->eliminar($_GET["id"]);

			echo '	<form method="post">
						<input type="submit" name="volver" value="VOLVER">
					</form>';
		}else{
			if(isset($_POST["no"])){
				header("Location: index.php");
			}else{
				if (isset($_POST["volver"])) {
					header("Location: index.php");
				}
			}
		}
	
?>

