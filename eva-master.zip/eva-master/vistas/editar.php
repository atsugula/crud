<?php 

	$controlador=new controlador();
	$reg=$controlador->ver($_GET["id"]);

 ?>

	<h2>ESTAS EN EL MÓDULO EDITAR</h2>
	
	<form method="post">
		<table border="2">
			<tr>
				<th> CODIGO DEL PRODUCTO:<br></th>
				<th><input type="text" name="cod" value="<?php echo $reg["cod"]?>"><br></th>
			</tr>
			<tr>
				<th>DESCRIPCION DEL PRODUCTO: <br></th>
				<th><input type="text" name="descripcion" value="<?php echo $reg["descripcion"]?>"><br></th>
			</tr>
			<tr>
				<th>STOCK DEL PRODUCTO: <br></th>
				<th><input type="text" name="stock" value="<?php echo $reg["stock"]?>"><br></th>
			</tr>
			<tr>
				<td><input type="submit" name="enviar" value="ENVIAR"></td>
			</tr>
		</table>
	</form>
	
<?php 




	$controlador=new controlador();//para crear personas antes hay que iniciarlo

	$tempo=$_POST["stock"];

	if (isset($_POST["enviar"])){
			$res=$controlador->editar($_GET["id"],$_POST["cod"],$_POST["descripcion"],$_POST["stock"]);

	if($_POST["stock"]<=5){
				echo "	<script>
							alert('STOCK MENOR A 5');
						</script>";

			}

	if($res){
		echo "<script>
			alert('El producto ha sido editado correctamente');
			window.location='index.php'
			</script>";
		//header("location:index.php");	

	}else{
		echo "<script>alert('El producto no existe');</script>";
		

	}

}

?>