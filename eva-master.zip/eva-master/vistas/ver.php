<?php
	$controlador=new controlador();

	$reg=$controlador->ver($_GET["id"]);
?>
	<form>
		<table border="2">
			<tr>
				<th>CODIGO DEL PRODUCTO: </th>
				<th colspan="2"><input type="text" size="63" value="<?php echo $reg["cod"]?>"disabled></th>
			</tr>
			<tr>
				<th>DESCRIPCION DEL PRODUCTO: </th>
				<th colspan="2"><input type="text" size="63" value="<?php echo $reg["descripcion"]?>" disabled></th>
			</tr>
			<tr>
				<th>STOCK DEL PRODUCTO: </th>
				<th colspan="2"><input type="text" size="63" value="<?php echo $reg["stock"]?>" disabled></th>
			</tr>
			<tr>
				<td><input type="submit" formenctype="index.php" value="VOLVER"></td>
			</tr>
		</table>
	</form>
